# Addressing LHC challenges by ML

This repository contains materials and programming assignments for online course [Addressing Large Hadron Collider challenges by ML](https://www.coursera.org/learn/hadron-collider-machine-learning/home/welcome)