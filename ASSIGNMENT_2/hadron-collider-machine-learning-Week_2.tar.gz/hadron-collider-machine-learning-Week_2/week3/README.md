# Week3 programming assignment


## FILES at the release
training.csv - all features
check_agreement.csv - all features but mass for agreement check
check_correlation.csv - all features for correlation check
test.csv - all features but mass
